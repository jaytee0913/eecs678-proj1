var searchData=
[
  ['type',['Type',['../deque_8h.html#ac9c83c2070eb6b5891cf742b90f54c68',1,'deque.h']]]
];
