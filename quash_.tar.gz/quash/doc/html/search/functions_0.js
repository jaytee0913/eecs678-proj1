var searchData=
[
  ['apply_5fexample',['apply_Example',['../deque_8h.html#a582c40f070af171e4c98455d7d6fd305',1,'deque.h']]],
  ['as_5farray_5fexample',['as_array_Example',['../deque_8h.html#a0214e3a819ca3e1ec44d2f60d7c28f7b',1,'deque.h']]]
];
