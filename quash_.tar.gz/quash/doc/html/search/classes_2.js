var searchData=
[
  ['genericcommand',['GenericCommand',['../structGenericCommand.html',1,'']]]
];
