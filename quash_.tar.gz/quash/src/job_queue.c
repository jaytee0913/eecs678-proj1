#include "job_queue.h"

IMPLEMENT_DEQUE (job_queue, job_struct);
